import { base64Data, foodBase64 } from './images';
import { navigation_links, contact_navigations } from './navigation';
import storage from './storage';
export {
  navigation_links,
  contact_navigations,
  base64Data,
  foodBase64,
  storage,
};
