export const navigation_links = [
  { title: 'Home', to: '/' },
  { title: 'Menu', to: '/findfood' },
  { title: 'Bookings', to: '/bookings' },
  { title: 'Book A Table', to: '/bookingForm' },
];

export const contact_navigations = [
  { title: '678 Pisa Ave, Chicago, IL 60611s', to: '!#' },
  {
    title: '(312) 593-2744',
    to: 'tel:+3125932744',
  },

  {
    title: 'customer@littlelemon.com',
    to: 'mailto:customer@littlelemon.com',
  },
];
